// My first paragraph:
let paragraph = document.getElementById("txtMyWorld");
paragraph.innerHTML = "You are now in Lubben-Ortiz's world!";
